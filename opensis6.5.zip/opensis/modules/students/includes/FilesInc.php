<?php
#**************************************************************************
#  openSIS is a free student information system for public and non-public
#  schools from Open Solutions for Education, Inc. web: www.os4ed.com
#
#  openSIS is  web-based, open source, and comes packed with features that
#  include student demographic info, scheduling, grade book, attendance,
#  report cards, eligibility, transcripts, parent portal,
#  student portal and more.
#
#  Visit the openSIS web site at http://www.opensis.com to learn more.
#  If you have question regarding this system or the license, please send
#  an email to info@os4ed.com.
#
#  This program is released under the terms of the GNU General Public License as
#  published by the Free Software Foundation, version 2 of the License.
#  See license.txt.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#***************************************************************************************
include('../../../RedirectIncludes.php');
$dir='assets/studentfiles';
if($_REQUEST['modfunc']=='delete' && (User('PROFILE')=='admin' || User('PROFILE')=='student'))
{
	if(!$_REQUEST['delete_ok'] && !$_REQUEST['delete_cancel'])
        {
		echo '</FORM>';
        }
	if(DeletePromptMod($_REQUEST['title'],'&include=FilesInc&category_id=7'))
	{
                        unlink($_REQUEST['file']);
                        unset($_REQUEST['modfunc']);
	}
}

if(isset($_REQUEST['delete_msg']) && $_REQUEST['delete_msg']=='yes')
{
    
   unlink($_REQUEST['target_path']);
   unset($_SESSION['grid_msg']);
   unset($_SESSION['dup_file_name']);
}
if(!$_REQUEST['modfunc'])
{
    unset($_SESSION['grid_msg']);
    unset($_SESSION['dup_file_name']);
    ###########################File Upload ####################################################

if(!file_exists($dir))
{
    mkdir($dir,0777);
}
if($_FILES['uploadfile']['name'])
{
     $_FILES['uploadfile']['name']=str_replace(" ","opensis_space_here",$_FILES['uploadfile']['name']);
          $allowFiles=array("jpg","jpeg","png","gif","bmp","doc","docx","xls","xlsx","ppt","pptx","pps","txt","pdf");
                  $target_path=$dir.'/'.UserStudentID().'-'.$_FILES['uploadfile']['name'];
              if(file_exists($target_path))
              {
               $target_path=$dir.'/'.UserStudentID().'-'.$_FILES['uploadfile']['name']."-_".time(); 
               $_SESSION['dup_file_name']=$target_path;
               $_SESSION['grid_msg']='block';
              }
               $destination_path=$dir;
                $upload= new upload();
                $upload->target_path=$target_path;
                $upload->destination_path=$destination_path;
                $upload->name=$_FILES["uploadfile"]["name"];
                $upload->setFileExtension();
                $upload->fileExtension;
                $upload->allowExtension=$allowFiles;
	$upload->validateImage();
	if($upload->wrongFormat==1)
        {
        $_FILES["uploadfile"]["error"]=1;
	}
                if ($_FILES["uploadfile"]["error"] > 0)
                {
                        $msg = '<span style="color: #C90000; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">Cannot upload file. Invalid file type.</span>';
                }
                else
                {
                        if(!move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $upload->target_path))
                                $msg= '<span style="color: #C90000; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">Cannot upload file. Invalid Permission</span>';
                        else
                        {
                            
                           $target_path1=$dir.'/'.UserStudentID().'-'.$_FILES['uploadfile']['name']; 
                            if(file_exists($target_path1) && file_exists($_SESSION['dup_file_name']))
                            {
                
                            $n=DuplicateFile("duplicate file",$_SESSION['dup_file_name']);
                            }
                                $msg='<span style="color: #669900; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">Successfully uploaded</span>';
                
                        }
                }
                unset ($_FILES['uploadfile']);
 
}
if(!isset($_SESSION['grid_msg']))
        {
        if($msg)
        {
                echo $msg;
        }
        echo '<table width="100%" class="grid" cellpadding="4" cellspacing="1">';
        
        if(AllowEdit ())
        {
        echo '<thead><tr><td colspan=2 class="subtabs">To upload additional files click browse, select file, give it a file name and click save</td></tr></thead>';
        }
        else 
        {
        echo '<thead><tr><td colspan=2 class="subtabs">To View a certain file,click on the name of the file</td></tr></thead>';
        }

        echo '<tr class="odd">';
        if(AllowEdit ())
        {
        echo 	'<td width="50%" colspan=2><input type="file" name="uploadfile" size=50 id="upfile"></td>';
        }
        echo '</tr>';

         $dir=dir($dir);
         echo '<tbody>';
         $found=false;
        $gridClass = "odd";
        
        while($filename=$dir->read()) {
            if($gridClass=="even")
            {
                $gridClass="odd";
            }
            else
            {
                $gridClass="even";
            }
          if($filename)
          {
            if($filename=='.' || $filename=='..')
            continue;

            $student_id_up = explode('-',$filename);

            if($student_id_up[0]==UserStudentID())
            {
                $found=true;
                echo "<br>";

                echo "<br>";
                $sub=substr($filename,strpos($filename,'-')+1);

               if(strstr($sub,'-_'))
               {
                $file_display= substr($sub,0,strrpos($sub,'-_'));
               }
 else {
     $file_display=$sub;
 }
 
                 echo '<tr class="'.$gridClass.'">
                          <td><a target="new" href="assets/studentfiles/'.$filename.'">'.str_replace("opensis_space_here"," ",$file_display).'</a></td>
                          ';

                  if(AllowEdit ())
                     {
                      echo '<td><input type="hidden" name="del" value="assets/studentfiles/'.$filename.'"/>
                          <a href=Modules.php?modname='.$_REQUEST[modname].'&include=FilesInc&file=assets/studentfiles/'.urlencode($filename).'&modfunc=delete><img src="assets/remove_button.gif" border=0 vspace=0></a>
                              </td>';
                     }
                   
                     echo ' </tr>';

            }
        }
        }

         $dir->close();
         echo '</tbody>';
         echo '</table>';
        if($found!=true)
        {
            echo '<span class="alert_msg">No Files were found.</span>';
        }
        }
}


?>
